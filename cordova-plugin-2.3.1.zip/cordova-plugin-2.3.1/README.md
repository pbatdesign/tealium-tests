## Tealium Cordova Plugin

[![License](https://img.shields.io/badge/license-Proprietary-blue.svg?style=flat
           )](https://github.com/Tealium/cordova-plugin/blob/master/LICENSE.txt)
![Platform](https://img.shields.io/badge/platform-iOS%20android-lightgrey.svg?style=flat
             )
![Language](https://img.shields.io/badge/language-javascript%20kotlin%20swift-orange.svg)


## Documentation
For full documentation, please see the Tealium Developer Docs: 

[https://docs.tealium.com/platforms/cordova/](https://docs.tealium.com/platforms/cordova/)

## License

Use of this software is subject to the terms and conditions of the license agreement contained in the file titled "LICENSE.txt".  Please read the license before downloading or using any of the files contained in this repository. By downloading or using any of these files, you are agreeing to be bound by and comply with the license agreement.

 
---
Copyright (C) 2012-2021, Tealium Inc.